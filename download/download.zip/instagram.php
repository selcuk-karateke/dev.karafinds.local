<?php
session_start();
require 'config.php';
require 'functions.php';
$scope = 'instagram_basic,instagram_manage_comments';
$oauthUrl = 'https://api.instagram.com/oauth/';
// URL für die Benutzerauthentifizierung bauen
$authUrl = $oauthUrl . "authorize?client_id=" . CLIENT_ID . "&redirect_uri=" . REDIRECT_URI . "&scope={$scope}&response_type=code";
// Link zur Authentifizierungsseite
$linkToAuth = "<a href='{$authUrl}'>Login with Instagram to manage comments</a>";


if (isset($_GET['code'])) {
    $code = $_GET['code'];  // Code erhalten nach Nutzer-Zustimmung
    $accessToken = getAccessToken($code, CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
    if ($accessToken) {
        $_SESSION['access_token'] = $accessToken;
        $tokenStatus = checkAccessTokenValidity($accessToken, CLIENT_ID, CLIENT_SECRET);
        if ($tokenStatus['is_valid']) {
            $message = "Access Token ist gültig.";
            // Hier könnten Sie die Funktion fetchComments aufrufen
        } else {
            $message = "Access Token ist ungültig.";
        }
    } else {
        $message = "Fehler beim Abrufen des Access Tokens.";
    }
} else {
    $message = "Kein Autorisierungscode verfügbar.";
}


?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <title>Dev Instagram - Webdesign Karateke</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="container">
        <header>
            <h1>Instagram</h1>
            <?php include 'parts/nav.htm'; ?>
        </header>
        <section>
            <h2>Message</h2>
            <?php echo $linkToAuth ?>
            <p><?php echo $message ?></p>
        </section>
        <footer>
            © 2023 Webdesign Karateke - Alle Rechte vorbehalten.
        </footer>
    </div>
</body>

</html>