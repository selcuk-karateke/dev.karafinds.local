<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <title>Startseite - Webdesign Karateke</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="container">
        <header>
            <h1>Willkommen bei Webdesign Karateke</h1>
            <?php include 'parts/nav.htm'; ?>
        </header>
        <section>
            <h2></h2>
            <p></p>
        </section>
        <footer>
            © 2023 Webdesign Karateke - Alle Rechte vorbehalten.
        </footer>
    </div>
</body>

</html>