<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    <title>Datenschutzrichtlinie - Webdesign Karateke</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="container">
        <header>
            <h1>Datenschutzrichtlinie für Webdesign Karateke</h1>
            <?php include 'parts/nav.htm'; ?>
        </header>
        <section>
            <h2>Policies</h2>
            <p><strong>1. Einführung</strong><br>
                Willkommen bei Webdesign Karateke. Wir respektieren Ihre Privatsphäre und verpflichten uns, Ihre persönlichen Daten nicht zu sammeln. Diese Datenschutzrichtlinie informiert Sie darüber, wie wir mit Informationen umgehen, die während Ihres Besuchs auf unserer Website nicht erhoben werden.</p>

            <p><strong>2. Daten, die wir nicht sammeln</strong><br>
                Wir sammeln keine persönlichen Daten über Besucher unserer Website. Dazu gehören keine Namen, Adressen, Telefonnummern oder E-Mail-Adressen.</p>

            <p><strong>3. Cookies und ähnliche Technologien</strong><br>
                Wir verwenden keine Cookies oder ähnliche Technologien, die darauf ausgerichtet sind, Daten über Sie zu sammeln.</p>

            <p><strong>4. Änderungen an dieser Datenschutzrichtlinie</strong><br>
                Wir können diese Datenschutzrichtlinie von Zeit zu Zeit aktualisieren. Wir empfehlen Ihnen, diese Seite regelmäßig auf Änderungen zu überprüfen.</p>

            <p><strong>5. Kontaktieren Sie uns</strong><br>
                Wenn Sie Fragen zu dieser Datenschutzrichtlinie haben, kontaktieren Sie uns bitte über [Ihre Kontakt-E-Mail-Adresse oder Kontaktseite-URL].</p>

            <p>Hier können Sie einen Absatz über Ihr Unternehmen und Ihre Dienstleistungen einfügen. Beschreiben Sie, was Ihr Unternehmen einzigartig macht und warum Kunden sich für Sie entscheiden sollten.</p>
        </section>
        <footer>
            © 2023 Webdesign Karateke - Alle Rechte vorbehalten.
        </footer>
    </div>
</body>

</html>