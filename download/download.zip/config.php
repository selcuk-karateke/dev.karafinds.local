<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// define("CLIENT_ID", "771961640169767");
define("CLIENT_ID", "3172388802893756");
define("CLIENT_SECRET", "2e8dacbc099a8eccb9ef1b03653c8b9a");
define("REDIRECT_URI", "https://dev.karafinds.com/instagram.php");

$access_token = "EAAtFRVOvl7wBO2BbXisYCug0kk6DFak27afzZCAD1JPAw0Hfmic0uz7DLGo0BE6MAH6S1ADaUvu9cwJsKT8RshKSXyBxudYB299xOBNON0uTl7C6EoMm5DggHUR0wG6TBlwe5YWYOyIvSxP5yVbXV0gG00fnAfA39lilXBIZCSBsa3bPL5S5TvXKMQmufoiMZBUcsQi1gZDZD";
